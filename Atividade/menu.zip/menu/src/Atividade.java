import java.util.ArrayList;
import java.util.Scanner;

public class Atividade {
    private Scanner scan;

    public Atividade(){
        this.scan = new Scanner(System.in);
    }

    public void Executar(){
        this.ExibirMenu();
    }

    private void ExibirMenu(){
        int continuar = 99;
        ArrayList<Integer> listinha = new ArrayList<Integer>();
        int op;

        do
        {
            System.out.println("\n\tChat Forever Alone\n\n");
            System.out.println("1. Lista int\n");
            System.out.println("2. lista completa\n");
            System.out.println("3. quadrado de uma posicao\n");
            System.out.println("4. dobro, tripo e a raiz do primeiro numero\n");
            System.out.println("5. ultimo numero da lista elevad a x.\n");
            System.out.println("0. Sair\n");
            continuar = this.scan.nextInt();
            switch(continuar)
            {
            case 1:
                
                listinha = this.PreencheLista();
                break;
            case 2:
                System.out.println(listinha);
                break;
            case 3:
                System.out.println("Digite a posicao do numero.");
                op = this.scan.nextInt();               
                System.out.println("Quadrado: " + listinha.indexOf(op) * listinha.indexOf(op));
                break;
            case 4:
                System.out.println("Dobro: " + listinha.indexOf(0) * 2);
                System.out.println("Triplo: " + listinha.indexOf(0) * 3);
                System.out.println("Raiz: " + Math.sqrt(listinha.indexOf(0)));
                break;
            case 5:
                System.out.println("Informe o X.");
                op = this.scan.nextInt();
                System.out.println("Resultado: " + listinha.indexOf(listinha.size() * op));
                break;
            default:
                System.out.println("Digite uma opção válida\n");
            }
        } while(continuar != 0); 
    }

    private ArrayList<Integer> PreencheLista(){
        ArrayList<Integer> lista = new ArrayList<Integer>();
        int opcao = 99;
        int pick;

        do{
            pick = this.scan.nextInt();
            lista.add(pick);
            System.out.println("Digite -1 para finalizar.");
        }while(opcao != -1);

        return lista;
    }
}
