public class App {
    public static void main(String[] args) throws Exception {
        Exemplo a = new Exemplo();
        Atividade b = new Atividade();
        
        a.Executar();

        b.Executar();
    }
}
