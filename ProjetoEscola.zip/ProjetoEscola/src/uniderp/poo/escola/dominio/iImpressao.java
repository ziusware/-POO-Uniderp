package uniderp.poo.escola.dominio;

public interface iImpressao {

    void Imprimir();
    
}
