import java.time.LocalDate;

import uniderp.poo.escola.dominio.Aluno;

public class App {
    public static void main(String[] args) throws Exception {
        Aluno  a1 = new Aluno(12,
        LocalDate.now(),
        "Rua bla bla, 9",
        "2323123",
        "AJA",
        "1234567",
        "6484817894",
        LocalDate.of(1111, 10, 1),
        "3323123131231",
        LocalDate.of(2020, 11, 23));
        
        a1.Imprimir();
    }
}
